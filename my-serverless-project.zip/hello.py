def handler(event, context):
	return {"message": "hi there"}
